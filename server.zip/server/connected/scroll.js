<script type="text/javascript" src="xbMarquee.js"></script>
<script type="text/javascript">
<!--
	//set the marquee parameters
	function init() { rtl_marquee.start(); }
	var rtl_marquee_Text = 'JavaScript scrolling text';
	var rtl_marquee_Direction = 'left';
	var rtl_marquee_Contents='<span style="font-family:Comic Sans MS;font-size:12pt;white-space:nowrap;">' + rtl_marquee_Text + '</span>';
	rtl_marquee = new xbMarquee('rtl_marquee', '29px', '90%', 6, 100, rtl_marquee_Direction, 'scroll', rtl_marquee_Contents);
	window.setTimeout( init, 200);
-->
</script>
