<?php
$iplist = @file("../logs/block_ip.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
//$iparray = in_array($_SERVER["HTTP_X_FORWARDED_FOR"], $iplist);
$iparray = in_array($_SERVER["REMOTE_ADDR"], $iplist);

if($iparray){
      header("Location: http://192.168.4.100:8080/connected/");die;

}
else {
      header("Location: index.html");
}
?>
