<?php
  header("Location: index.php");
  $mac = $_GET['id'];
  $ip = $_SERVER["REMOTE_ADDR"];
  $file = "../logs/client.txt";
  $txtfile = fopen($file, "a");
  fwrite($txtfile, $mac." --> ".$ip."\n");
  fclose($txtfile);
?>
