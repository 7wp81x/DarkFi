<?php
  header("Location: http://192.168.4.100:8080/connected/");
  $ip = $_SERVER["REMOTE_ADDR"];
  $file = "../logs/block_ip.txt";
  $txtfile = fopen($file, "a");
  fwrite($txtfile, $ip."\n");
  fclose($txtfile);
?>
